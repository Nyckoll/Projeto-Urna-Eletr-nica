package classe;

public class Pessoa {
	
	private String nome;


//heran�a
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}